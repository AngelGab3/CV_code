CV de Angel Gabriel Munguia Velazquez

Sube el ZIP a Overleaf y selecciona XeLaTeX como compilador.
Archivo principal: CV_Gabriel_Velazquez.tex
Mantén la carpeta fonts junto al archivo .tex.

Diseño adaptado de la referencia Nicoinsilico: encabezado centrado,
tipografía sans serif, escala de grises, líneas de sección y fechas a la derecha.
Se conserva el contenido en inglés proporcionado por el autor.
